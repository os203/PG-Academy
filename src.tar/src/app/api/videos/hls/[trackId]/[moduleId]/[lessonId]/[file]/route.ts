import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import fs from "fs";
import path from "path";
import { db } from "@/lib/db";
import { verifyToken } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type RouteParams = {
  trackId: string;
  moduleId: string;
  lessonId: string;
  file: string;
};

async function getAuthorizedUser(trackId: string) {
  const decoded = await verifyToken();
  if (!decoded?.userId || !decoded?.role) return null;

  if (decoded.role === "ADMIN") return decoded;

  if (decoded.role === "INSTRUCTOR") {
    const track = await db.track.findUnique({ where: { id: trackId } });
    if (track?.instructorId === decoded.userId) return decoded;
    return null;
  }

  // Student check
  const enrollment = await db.enrollment.findFirst({
    where: { userId: decoded.userId, trackId },
  });
  
  if (enrollment) return decoded;
  return null;
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<RouteParams> }
) {
  const { trackId, moduleId, lessonId, file } = await params;

  try {
    const user = await getAuthorizedUser(trackId);

    if (!user) {
      return new NextResponse("Unauthorized", { status: 401 });
    }

    // Protect against directory traversal
    if (file.includes("..") || file.includes("/")) {
      return new NextResponse("Invalid file path", { status: 400 });
    }

    const storageRoot = process.env.VIDEO_STORAGE_ROOT || "./private/videos";
    const hlsRoot = process.env.VIDEO_HLS_DIR || path.join(storageRoot, "hls");
    
    const filePath = path.join(hlsRoot, trackId, moduleId, lessonId, file);

    if (!fs.existsSync(filePath)) {
      return new NextResponse("File not found", { status: 404 });
    }

    const stat = fs.statSync(filePath);
    
    // Determine content type
    let contentType = "application/octet-stream";
    if (file.endsWith(".m3u8")) {
      contentType = "application/vnd.apple.mpegurl";
    } else if (file.endsWith(".ts")) {
      contentType = "video/MP2T";
    }

    // Create a read stream and return it
    const stream = fs.createReadStream(filePath);
    
    // Convert Node stream to Web ReadableStream
    const readableStream = new ReadableStream({
      start(controller) {
        stream.on("data", (chunk: any) => controller.enqueue(new Uint8Array(chunk)));
        stream.on("end", () => controller.close());
        stream.on("error", (err: Error) => controller.error(err));
      },
      cancel() {
        stream.destroy();
      }
    });

    const headers = new Headers();
    headers.set("Content-Type", contentType);
    headers.set("Content-Length", stat.size.toString());
    
    // Add CORS headers to allow the player to fetch segments if needed
    headers.set("Access-Control-Allow-Origin", "*");
    headers.set("Access-Control-Allow-Methods", "GET, OPTIONS");
    
    return new NextResponse(readableStream, {
      status: 200,
      headers,
    });
  } catch (error) {
    console.error("[HLS_STREAM_ERROR]", error);
    return new NextResponse("Internal Server Error", { status: 500 });
  }
}
