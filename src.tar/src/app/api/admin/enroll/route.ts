import { NextRequest, NextResponse } from "next/server";
import { cookies } from "next/headers";
import { db } from "@/lib/db";
import { verifyToken } from "@/lib/auth";

export async function POST(req: NextRequest) {
  try {
    const decoded = await verifyToken();
    if (!decoded?.userId || decoded.role !== "ADMIN") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const body = await req.json();
    const { userId, trackId } = body;

    if (!userId || !trackId) {
      return NextResponse.json(
        { error: "userId and trackId are required" },
        { status: 400 }
      );
    }

    // Verify user exists
    const user = await db.user.findUnique({
      where: { id: userId },
      select: { id: true, name: true, role: true },
    });

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // Verify track exists
    const track = await db.track.findUnique({
      where: { id: trackId },
      select: { id: true, title: true },
    });

    if (!track) {
      return NextResponse.json({ error: "Track not found" }, { status: 404 });
    }

    // Check if already enrolled
    const existing = await db.enrollment.findFirst({
      where: { userId, trackId },
    });

    if (existing) {
      return NextResponse.json(
        { error: "User is already enrolled in this track", alreadyEnrolled: true },
        { status: 409 }
      );
    }

    // Create enrollment
    const enrollment = await db.enrollment.create({
      data: { userId, trackId },
    });

    return NextResponse.json(
      {
        message: `${user.name} has been enrolled in "${track.title}"`,
        enrollment,
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("[ADMIN_ENROLL_ERROR]", error);
    return NextResponse.json({ error: "Internal Error" }, { status: 500 });
  }
}
